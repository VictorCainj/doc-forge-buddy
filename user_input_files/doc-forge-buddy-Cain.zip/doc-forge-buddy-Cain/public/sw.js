// Este arquivo é gerado automaticamente pelo vite-plugin-pwa
// Não edite manualmente - será sobrescrito no build
