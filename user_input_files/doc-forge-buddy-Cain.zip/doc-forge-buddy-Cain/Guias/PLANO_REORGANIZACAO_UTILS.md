# Plano de Reorganização da Pasta Utils

## ⚠️ Nota Importante

A reorganização da pasta `src/utils/` não foi implementada nesta sessão por representar um **risco alto de quebrar imports**.

## 🎯 Justificativa

### Por que não implementamos agora?

1. **Mais de 100 arquivos** importam de `@/utils/`
2. **Alto risco** de quebrar o build
3. **Sem automação** de migração de imports
4. **Requer testes extensivos** após reorganização
5. **Tempo estimado:** 2-3 dias de trabalho

## 📋 Estrutura Proposta

```
src/utils/
├── validation/
│   ├── inputValidation.ts
│   ├── inputValidator.ts
│   ├── securityValidators.ts
│   ├── passwordPolicy.ts
│   ├── phoneValidator.ts
│   ├── dataValidator.ts
│   └── index.ts
├── formatting/
│   ├── dateFormatter.ts
│   ├── dateHelpers.ts
│   ├── nameHelpers.ts
│   ├── copyTextUtils.ts
│   └── index.ts
├── image/
│   ├── imageOptimization.ts
│   ├── imageValidation.ts
│   ├── imageUpload.ts
│   ├── imageToBase64.ts
│   ├── imageHD.ts
│   ├── imageSerialGenerator.ts
│   ├── removeImageFromHTML.ts
│   ├── limitImagesPerApontamento.ts
│   ├── imageCompression.ts
│   └── index.ts
├── ai/
│   ├── openai.ts
│   ├── aiCache.ts
│   ├── contextEnricher.ts
│   ├── responseGenerator.ts
│   ├── responseHumanizer.ts
│   ├── responseTemplates.ts
│   ├── sentimentAnalysis.ts
│   ├── advancedSentimentAnalyzer.ts
│   ├── advancedTextAnalysis.ts
│   └── index.ts
├── document/
│   ├── docxGenerator.ts
│   ├── pdfExport.ts
│   ├── generateHTMLReport.ts
│   ├── vistoriaDocumentGenerator.ts
│   ├── fontSizeCalculator.ts
│   └── index.ts
└── core/
    ├── logger.ts
    ├── toastHelpers.ts
    ├── typeGuards.ts
    ├── permissions.ts
    ├── performanceConfig.ts
    ├── pwaHelpers.ts
    ├── cacheManager.ts
    ├── chatMetrics.ts
    └── index.ts
```

## 🔧 Implementação Futura

### Etapa 1: Preparação (1-2 horas)

1. Criar script de migração de imports
2. Criar barrel exports em cada subpasta
3. Fazer backup do projeto

### Etapa 2: Execução (2-3 horas)

1. Criar subpastas
2. Mover arquivos categorizados
3. Executar script de migração de imports
4. Executar `npm run build` para detectar erros

### Etapa 3: Validação (2-3 horas)

1. Executar testes unitários
2. Testar app manualmente
3. Validar que todos os imports funcionam
4. Reverter se necessário (git)

### Etapa 4: Cleanup (1 hora)

1. Remover barrel exports duplicados
2. Atualizar documentação
3. Commit

## 📝 Script de Migração Sugerido

```typescript
// scripts/migrate-utils-imports.ts
import { execSync } from 'child_process';
import * as fs from 'fs';

const mappings = {
  inputValidation: 'validation',
  dateFormatter: 'formatting',
  imageUpload: 'image',
  openai: 'ai',
  docxGenerator: 'document',
  logger: 'core',
  // ... mais mapeamentos
};

function migrateImports(file: string) {
  let content = fs.readFileSync(file, 'utf8');

  for (const [oldPath, newPath] of Object.entries(mappings)) {
    const pattern = new RegExp(`@/utils/${oldPath}`, 'g');
    content = content.replace(pattern, `@/utils/${newPath}/${oldPath}`);
  }

  fs.writeFileSync(file, content);
}
```

## ✅ Alternativa: Manter Como Está

**Decisão tomada:** Manter estrutura atual de `utils/`

**Motivos:**

1. ✅ Funciona perfeitamente
2. ✅ Todos os imports funcionam
3. ✅ Sem risco de quebra
4. ✅ Estrutura existente é aceitável

**Quando reconsiderar:**

- Quando projeto atingir 100+ arquivos em utils/
- Quando tivermos tempo dedicado (3-5 dias)
- Quando tivermos testes automatizados robustos

## 🎯 Conclusão

**Status:** Não implementado - Baixa prioridade

**Recomendação:** Manter estrutura atual e focar em features de maior valor para o projeto.
