import Contratos from './Contratos';

// Index redireciona para página de Contratos
export default Contratos;
