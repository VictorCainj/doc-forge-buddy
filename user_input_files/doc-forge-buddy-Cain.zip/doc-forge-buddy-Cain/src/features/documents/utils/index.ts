export {
  replaceTemplateVariables,
  isMultipleLocatarios,
  isTerceiraPessoa,
} from './templateProcessor';
