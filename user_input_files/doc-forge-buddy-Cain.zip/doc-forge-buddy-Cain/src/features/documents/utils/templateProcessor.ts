/**
 * @deprecated Use functions from '@/shared/template-processing' instead
 * Este arquivo é mantido apenas para compatibilidade com imports existentes
 */
export {
  replaceTemplateVariables,
  isMultipleLocatarios,
  isTerceiraPessoa,
} from '@/shared/template-processing';
