/**
 * Componente de sino/badge de notificações para o header
 */

import React from 'react';
import { NotificationDropdown } from './NotificationDropdown';

export const NotificationBell: React.FC = () => {
  return <NotificationDropdown />;
};
