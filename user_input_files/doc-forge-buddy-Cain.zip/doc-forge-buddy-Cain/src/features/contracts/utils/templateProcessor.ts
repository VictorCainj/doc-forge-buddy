/**
 * @deprecated Use processContractTemplate from '@/shared/template-processing' instead
 * Este arquivo é mantido apenas para compatibilidade com imports existentes
 */
export { processContractTemplate } from '@/shared/template-processing';
