export { applyContractConjunctions } from './contractConjunctions';
export { processContractTemplate } from './templateProcessor';
